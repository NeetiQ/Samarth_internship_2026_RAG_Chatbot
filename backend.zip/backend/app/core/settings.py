from pydantic_settings import BaseSettings, SettingsConfigDict
from pydantic import field_validator, ValidationInfo
from functools import lru_cache
from typing import List, Optional

class Settings(BaseSettings):
    PROJECT_NAME: str = "Legal RAG API"
    API_V1_STR: str = "/api/v1"
    DEBUG: bool = True
    ENVIRONMENT: str = "development"
    
    # Database
    POSTGRES_SERVER: Optional[str] = None
    POSTGRES_USER: Optional[str] = None
    POSTGRES_PASSWORD: Optional[str] = None
    POSTGRES_DB: Optional[str] = None
    POSTGRES_PORT: Optional[int] = None
    
    # Database URL has no default; it is required.
    DATABASE_URL: str
    
    @field_validator("DATABASE_URL", mode="before")
    @classmethod
    def validate_database_url(cls, v: Optional[str], info: ValidationInfo) -> str:
        if not v:
            raise ValueError("DATABASE_URL environment variable is missing. A valid database connection string is required.")
        
        env = info.data.get("ENVIRONMENT", "production")
        if env == "production":
            if "localhost" in v or "127.0.0.1" in v:
                raise ValueError("Production environment should never connect to localhost.")
            if "postgres:postgres@" in v:
                raise ValueError("Production environment should never use default development credentials.")
        
        # Cloud providers often inject postgres:// or postgresql:// natively. 
        # We rewrite it to the asyncpg dialect required by SQLAlchemy.
        if v.startswith("postgres://"):
            v = v.replace("postgres://", "postgresql+asyncpg://", 1)
        elif v.startswith("postgresql://"):
            v = v.replace("postgresql://", "postgresql+asyncpg://", 1)
            
        return v
    
    # Storage
    STORAGE_DIR: str = "./data/uploads"
    MAX_UPLOAD_SIZE_MB: int = 50
    SUPPORTED_FILE_TYPES: List[str] = ["application/pdf", "image/png", "image/jpeg"]
    
    # Ingestion & Chunking
    CHUNK_SIZE: int = 500
    CHUNK_OVERLAP: int = 50
    OCR_ENGINE: str = "PaddleOCR"
    OCR_LANGUAGE: str = "en"
    
    # Embeddings & Retrieval
    EMBEDDING_MODEL_NAME: str = "BAAI/bge-small-en-v1.5"
    EMBEDDING_DIMENSION: int = 384
    RETRIEVAL_TOP_K: int = 5
    RERANKER_MODEL_NAME: str = "cross-encoder/ms-marco-MiniLM-L-6-v2"
    RERANKER_TOP_K: int = 3
    
    # LLM
    GEMINI_API_KEY: str = ""
    GEMINI_MODEL: str = "gemini-2.5-flash"
    
    # Corpus seeding (deployment)
    SEED_CORPUS: bool = True
    CHUNKED_DOCUMENTS_PATH: str = "./chunked_documents.jsonl"
    EMBEDDED_DOCUMENTS_PATH: str = "./embedded_documents.jsonl"
    GENERATE_EMBEDDINGS_ON_SEED: bool = False
    
    # JWT / Auth
    SECRET_KEY: str = "CHANGE-ME-IN-PRODUCTION"
    ALGORITHM: str = "HS256"
    ACCESS_TOKEN_EXPIRE_MINUTES: int = 60
    
    model_config = SettingsConfigDict(env_file=".env", env_file_encoding="utf-8", case_sensitive=True, extra="ignore")


@lru_cache()
def get_settings():
    return Settings()
